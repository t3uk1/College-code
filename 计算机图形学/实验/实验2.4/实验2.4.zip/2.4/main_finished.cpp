//#include "include/Angel.h"
//#include "include/TriMesh.h"
//
//#include <vector>
//#include <string>
//#include<iostream>
//using namespace std;
//
//const int X_AXIS = 0;
//const int Y_AXIS = 1;
//const int Z_AXIS = 2;
//
//const int TRANSFORM_SCALE = 0;
//const int TRANSFORM_ROTATE = 1;
//const int TRANSFORM_TRANSLATE = 2;
//
//const double DELTA_DELTA = 0.3;		// Delta�ı仯��
//const double DEFAULT_DELTA = 0.5;	// Ĭ�ϵ�Deltaֵ
//
//double scaleDelta = DEFAULT_DELTA;
//double rotateDelta = DEFAULT_DELTA;
//double translateDelta = DEFAULT_DELTA;
//
//glm::vec3 scaleTheta(1.0, 1.0, 1.0);		// ���ſ��Ʊ���
//glm::vec3 rotateTheta(0.0, 0.0, 0.0);    // ��ת���Ʊ���
//glm::vec3 translateTheta(0.0, 0.0, 0.0);	// ƽ�ƿ��Ʊ���
//
//int currentTransform = TRANSFORM_ROTATE;	// ���õ�ǰ�任
//
//bool is_dragging = false;
//bool is_lastPosRecord = false;
//
//int mainWindow;
//
//double lastX;
//double lastY;
//
//glm::mat4 arcball(1.0, 0.0, 0.0, 0.0,
//	0.0, 1.0, 0.0, 0.0,
//	0.0, 0.0, 1.0, 0.0,
//	0.0, 0.0, 0.0, 1.0);
//glm::mat4 arcball_pre(1.0, 0.0, 0.0, 0.0,
//	0.0, 1.0, 0.0, 0.0,
//	0.0, 0.0, 1.0, 0.0,
//	0.0, 0.0, 0.0, 1.0);
//
//struct openGLObject
//{
//	// �����������
//	GLuint vao;
//	// ���㻺�����
//	GLuint vbo;
//
//	// ��ɫ������
//	GLuint program;
//	// ��ɫ���ļ�
//	std::string vshader;
//	std::string fshader;
//	// ��ɫ������
//	GLuint pLocation;
//	GLuint cLocation;
//	GLuint matrixLocation;
//	GLuint darkLocation;
//};
//
//
//openGLObject cube_object;
//
//TriMesh* cube = new TriMesh();
//
//
//void bindObjectAndData(TriMesh* mesh, openGLObject& object, const std::string& vshader, const std::string& fshader) {
//
//	// ���������������
//	glGenVertexArrays(1, &object.vao);  	// ����1�������������
//	glBindVertexArray(object.vao);  	// �󶨶����������
//
//
//	// ��������ʼ�����㻺�����
//	glGenBuffers(1, &object.vbo);
//	glBindBuffer(GL_ARRAY_BUFFER, object.vbo);
//	glBufferData(GL_ARRAY_BUFFER,
//		mesh->getPoints().size() * sizeof(glm::vec3) + mesh->getColors().size() * sizeof(glm::vec3),
//		NULL,
//		GL_STATIC_DRAW);
//
//	// @TODO: �޸���TriMesh.cpp�Ĵ���ɺ��ٴ�����ע�ͣ��������ᱨ��
//	glBufferSubData(GL_ARRAY_BUFFER, 0, mesh->getPoints().size() * sizeof(glm::vec3), &mesh->getPoints()[0]);
//	glBufferSubData(GL_ARRAY_BUFFER, mesh->getPoints().size() * sizeof(glm::vec3), mesh->getColors().size() * sizeof(glm::vec3), &mesh->getColors()[0]);
//
//	object.vshader = vshader;
//	object.fshader = fshader;
//	object.program = InitShader(object.vshader.c_str(), object.fshader.c_str());
//
//	// �Ӷ�����ɫ���г�ʼ�������λ��
//	object.pLocation = glGetAttribLocation(object.program, "vPosition");
//	glEnableVertexAttribArray(object.pLocation);
//	glVertexAttribPointer(object.pLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
//
//	// �Ӷ�����ɫ���г�ʼ���������ɫ
//	object.cLocation = glGetAttribLocation(object.program, "vColor");
//	glEnableVertexAttribArray(object.cLocation);
//	glVertexAttribPointer(object.cLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(mesh->getPoints().size() * sizeof(glm::vec3)));
//
//	// ��þ���洢λ��
//	object.matrixLocation = glGetUniformLocation(object.program, "matrix");
//	object.darkLocation = glGetUniformLocation(object.program, "dark");
//}
//
//
//void init()
//{
//	std::string vshader, fshader;
//	// ��ȡ��ɫ����ʹ��
//	vshader = "shaders/vshader.glsl";
//	fshader = "shaders/fshader.glsl";
//
//	cube->generateCube();
//	bindObjectAndData(cube, cube_object, vshader, fshader);
//
//	// ��ɫ����
//	glClearColor(0.0, 0.0, 0.0, 1.0);
//}
//
//void display()
//{
//	// ��������
//	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
//
//	glUseProgram(cube_object.program);
//
//	glBindVertexArray(cube_object.vao);
//
//
//	// ��ʼ���任����
//	glm::mat4 m(1.0, 0.0, 0.0, 0.0,
//		0.0, 1.0, 0.0, 0.0,
//		0.0, 0.0, 1.0, 0.0,
//		0.0, 0.0, 0.0, 1.0);
//
//	// @TODO: �ڴ˴��޸ĺ������������յı任����
//	// ���ú����������ֱ仯�ı仯�����ۼӵõ��仯����
//	// ע�����ֱ仯�ۼӵ�˳��
//	glm::mat4 trans = glm::mat4(1.0f);
//	m = arcball * arcball_pre * m;
//
//	// ��ָ��λ��matrixLocation�д���任����m
//	glUniformMatrix4fv(cube_object.matrixLocation, 1, GL_FALSE, glm::value_ptr(m));
//
//	// �����������еĸ���������
//	glDrawArrays(GL_TRIANGLES, 0, cube->getPoints().size());
//}
//
//// ͨ��Deltaֵ����Theta
//void updateTheta(int axis, int sign) {
//	switch (currentTransform) {
//		// ���ݱ任���ͣ����ӻ����ĳ�ֱ任�ı仯��
//	case TRANSFORM_SCALE:
//		scaleTheta[axis] += sign * scaleDelta;
//		break;
//	case TRANSFORM_ROTATE:
//		rotateTheta[axis] += sign * rotateDelta;
//		break;
//	case TRANSFORM_TRANSLATE:
//		translateTheta[axis] += sign * translateDelta;
//		break;
//	}
//}
//
//void dark_time() {
//
//	GLfloat current_time = (float)glfwGetTime();
//	glUniform1f(cube_object.darkLocation, (sin(current_time) / 2.0f) + 0.5f);
//}
//
//// ��ԭTheta��Delta
//void resetTheta()
//{
//	scaleTheta = glm::vec3(1.0, 1.0, 1.0);
//	rotateTheta = glm::vec3(0.0, 0.0, 0.0);
//	translateTheta = glm::vec3(0.0, 0.0, 0.0);
//	scaleDelta = DEFAULT_DELTA;
//	rotateDelta = DEFAULT_DELTA;
//	translateDelta = DEFAULT_DELTA;
//}
//
//// ���±仯Deltaֵ
//void updateDelta(int sign)
//{
//	switch (currentTransform) {
//		// ���ݱ仯�������ӻ����ÿһ�α仯�ĵ�λ�仯��
//	case TRANSFORM_SCALE:
//		scaleDelta += sign * DELTA_DELTA;
//		break;
//	case TRANSFORM_ROTATE:
//		rotateDelta += sign * DELTA_DELTA;
//		break;
//	case TRANSFORM_TRANSLATE:
//		translateDelta += sign * DELTA_DELTA;
//		break;
//	}
//}
//
//void mouse_pos_callback(GLFWwindow* window, double xpos, double ypos)
//{
//	if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
//	{
//		is_dragging = true;
//	}
//			//lbutton_down = true;
//	else if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_RELEASE)
//	{	
//		if (is_dragging)
//		{
//			arcball_pre = arcball*arcball_pre;
//			arcball = glm::mat4(1.0, 0.0, 0.0, 0.0,
//				0.0, 1.0, 0.0, 0.0,
//				0.0, 0.0, 1.0, 0.0,
//				0.0, 0.0, 0.0, 1.0);
//		}
//		is_dragging = false;
//		is_lastPosRecord = false;
//	}
//
//	if (is_dragging)
//	{	
//		if (!is_lastPosRecord)
//		{
//			double xpos, ypos;
//			glfwGetCursorPos(window, &xpos, &ypos);
//			lastX = xpos;
//			lastY = ypos;
//			is_lastPosRecord = true;
//		}
//		double xpos, ypos;
//		glfwGetCursorPos(window, &xpos, &ypos);
//		int width, height;
//		glfwGetWindowSize(window, &width, &height);
//		float screen_width = width;
//		float screen_height = width;
//		float x0 = (float)(lastX - screen_width / 2);
//		float x1 = (float)(xpos - screen_width / 2);
//		float y0 = (float)((screen_height - lastY - 1) - screen_height / 2);
//		float y1 = (float)((screen_height - ypos - 1) - screen_height / 2);
//		float arcball_radius = (float)(screen_width > screen_height ? screen_width : screen_height);
//
//		// distances to center of arcball
//		float dist0 = sqrtf(x0 * x0 + y0 * y0);
//		float dist1 = sqrtf(x1 * x1 + y1 * y1);
//
//		float z0;
//		if (dist0 > arcball_radius)
//		{
//			// initial click was not on the arcball, so just do nothing.
//			return;
//		}
//		else
//		{
//			// compute depth of intersection using good old pythagoras
//			z0 = sqrtf(arcball_radius * arcball_radius - x0 * x0 - y0 * y0);
//		}
//		float z1;
//		if (dist1 > arcball_radius)
//		{
//			// started inside the ball but went outside, so clamp it.
//			x1 = (x1 / dist1) * arcball_radius;
//			y1 = (y1 / dist1) * arcball_radius;
//			dist1 = arcball_radius;
//			z1 = 0.0f;
//		}
//		else
//		{
//			// compute depth of intersection using good old pythagoras
//			z1 = sqrtf(arcball_radius * arcball_radius - x1 * x1 - y1 * y1);
//		}
//		glm::vec3 dir0(x0, y0, z0);
//		glm::vec3 dir1(x1, y1, z1);
//		float rotate_angle = glm::acos(glm::dot(glm::normalize(dir0), glm::normalize(dir1)));
//		std::cout << rotate_angle << std::endl;
//		if (rotate_angle <0.005)
//		{
//			return;
//		}
//		glm::mat4 identity(1.0, 0.0, 0.0, 0.0,
//			0.0, 1.0, 0.0, 0.0,
//			0.0, 0.0, 1.0, 0.0,
//			0.0, 0.0, 0.0, 1.0);
//		arcball = glm::rotate(identity, rotate_angle, glm::cross(dir1, dir0));
//	}
//}
//
//void printHelp() {
//	printf("%s\n\n", "3D Transfomations");
//	printf("Keyboard options:\n");
//	printf("1: Transform Scale\n");
//	printf("2: Transform Rotate\n");
//	printf("3: Transform Translate\n");
//	printf("q: Increase x\n");
//	printf("a: Decrease x\n");
//	printf("w: Increase y\n");
//	printf("s: Decrease y\n");
//	printf("e: Increase z\n");
//	printf("d: Decrease z\n");
//	printf("r: Increase delta of currently selected transform\n");
//	printf("f: Decrease delta of currently selected transform\n");
//	printf("t: Reset all transformations and deltas\n");
//}
//
//void cleanData() {
//	cube->cleanData();
//
//	// �ͷ��ڴ�
//	delete cube;
//	cube = NULL;
//
//	// ɾ���󶨵Ķ���
//	glDeleteVertexArrays(1, &cube_object.vao);
//
//	glDeleteBuffers(1, &cube_object.vbo);
//	glDeleteProgram(cube_object.program);
//}
//
//void framebuffer_size_callback(GLFWwindow* window, int width, int height);
//
//int main(int argc, char** argv)
//{
//	// ��ʼ��GLFW�⣬������Ӧ�ó�����õĵ�һ��GLFW����
//	glfwInit();
//
//	// ����GLFW
//	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
//	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
//	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
//
//#ifdef __APPLE__
//	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
//#endif
//
//	// ���ô�������
//	GLFWwindow* window = glfwCreateWindow(600, 600, "3D Transfomations", NULL, NULL);
//	if (window == NULL)
//	{
//		std::cout << "Failed to create GLFW window" << std::endl;
//		glfwTerminate();
//		return -1;
//	}
//	glfwMakeContextCurrent(window);
//	//glfwSetKeyCallback(window, key_callback);
//	glfwSetCursorPosCallback(window, mouse_pos_callback);
//	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
//
//	// �����κ�OpenGL�ĺ���֮ǰ��ʼ��GLAD
//	// ---------------------------------------
//	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
//	{
//		std::cout << "Failed to initialize GLAD" << std::endl;
//		return -1;
//	}
//
//	init();
//	// ���������Ϣ
//	printHelp();
//	// ������Ȳ���
//	glEnable(GL_DEPTH_TEST);
//	while (!glfwWindowShouldClose(window))
//	{
//		display();
//		//dark_time();
//		// ������ɫ���� �Լ� �����û�д���ʲô�¼�������������롢����ƶ��ȣ�
//		// -------------------------------------------------------------------------------
//		glfwSwapBuffers(window);
//		glfwPollEvents();
//	}
//
//	//glutIdleFunc(idle);
//	//glutMainLoop();
//
//	cleanData();
//
//
//	return 0;
//}
//
//// ÿ�����ڸı��С��GLFW�������������������Ӧ�Ĳ������㴦����
//// ---------------------------------------------------------------------------------------------
//void framebuffer_size_callback(GLFWwindow* window, int width, int height)
//{
//	// make sure the viewport matches the new window dimensions; note that width and 
//	// height will be significantly larger than specified on retina displays.
//	glViewport(0, 0, width, height);
//}