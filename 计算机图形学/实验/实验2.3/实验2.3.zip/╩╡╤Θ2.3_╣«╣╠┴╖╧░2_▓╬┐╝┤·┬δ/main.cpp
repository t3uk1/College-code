#include "Angel.h"
#include <string>
#include<iostream>
using namespace std;

const glm::vec3 WHITE(1.0, 1.0, 1.0);
const glm::vec3 BLACK(0.0, 0.0, 0.0);
const glm::vec3 RED(1.0, 0.0, 0.0);
const glm::vec3 GREEN(0.0, 1.0, 0.0);
const glm::vec3 BLUE(0.0, 0.0, 1.0);

const int TRIANGLE_NUM_POINTS = 3;
const int SQUARE_NUM = 1;
const int SQUARE_NUM_POINTS = 4 * SQUARE_NUM;
GLuint vao[2], program;

int start_x = 0;
int start_y = 0;

int current_x = 0;
int current_y = 0;

int delta_x = 0;
int delta_y = 0;

bool is_click = false;

GLuint mLocation;
GLuint mainWindow;

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

void init()
{
	// 读取着色器并使用
	std::string vshader, fshader;
    vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";

	program = InitShader(vshader.c_str(), fshader.c_str());

	// 创建顶点缓存对象
	GLuint vbo[2];
	glm::vec2 square_vertices[SQUARE_NUM_POINTS] = {
			glm::vec2(-0.50/2,-0.50/2),glm::vec2(0.50/2,-0.50/2),
			glm::vec2(0.50/2,0.50/2),glm::vec2(-0.50/2,0.50/2)

	};

	// 定义正方形的颜色
	glm::vec3 square_colors[SQUARE_NUM_POINTS] = {
		BLACK, BLACK, BLACK, RED
	};
	// 创建顶点数组对象
	glGenVertexArrays(1, &vao[1]);		// 分配1个顶点数组对象
	glBindVertexArray(vao[1]);			// 绑定顶点数组对象


	glGenBuffers(1, &vbo[0]);
	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(square_vertices), square_vertices, GL_STATIC_DRAW);

	GLuint location = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(location);
	glVertexAttribPointer(
		location,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(glm::vec2),
		BUFFER_OFFSET(0));

	mLocation = glGetUniformLocation(program, "matrix");

	// 白色背景
	glClearColor(0.0, 0.0, 0.0, 1.0);
}

void display(void)
{
	// 清理窗口
	glClear(GL_COLOR_BUFFER_BIT);

	glUseProgram(program);
	glBindVertexArray(vao[1]);

	glm::mat4 m(1.0, 0.0, 0.0, 0.0,
		0.0, 1.0, 0.0, 0.0,
		0.0, 0.0, 1.0, 0.0,
		0.0, 0.0, 0.0, 1.0);
	glm::mat4 trans = glm::mat4(1.0f);

	trans = glm::translate(trans, glm::vec3((current_x - start_x + delta_x) / 512.0 * 2.0, -(current_y - start_y + delta_y) / 512.0 * 2.0, 0));
	m = trans * m;

	glUniformMatrix4fv(mLocation, 1, GL_FALSE, glm::value_ptr(m));
	glDrawArrays(GL_TRIANGLE_FAN, 0, SQUARE_NUM_POINTS);

}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		double x, y;
		//getting cursor position
		glfwGetCursorPos(window, &x, &y);
		cout << "Cursor Position at (" << x << " : " << y << endl;
		if (!is_click) {
			cout << "mouse press" << endl;
			start_x = x;
			start_y = y;

			current_x = x;
			current_y = y;

			is_click = true;
		}
	}
	else if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE) {
		cout << "mouse release" << endl;
		is_click = false;
		delta_y = current_y - start_y + delta_y;
		delta_x = current_x - start_x + delta_x;

		start_x = 0;
		start_y = 0;

		current_x = 0;
		current_y = 0;
	}
}

void motion(GLFWwindow* window) {
	double x, y;
	//getting cursor position
	glfwGetCursorPos(window, &x, &y);
	current_x = x;
	current_y = y;
}

int main(int argc, char** argv)
{
	// 初始化GLFW库，必须是应用程序调用的第一个GLFW函数
	glfwInit();

	// 配置GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	#ifdef __APPLE__
		glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	#endif

	// 配置窗口属性
	GLFWwindow* window = glfwCreateWindow(512, 512, "3D Move", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	

	// 调用任何OpenGL的函数之前初始化GLAD
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();
	std::cout << "OpenGL Vendor: " << glGetString(GL_VENDOR) << std::endl;
	std::cout << "OpenGL Renderer: " << glGetString(GL_RENDERER) << std::endl;
	std::cout << "OpenGL Version: " << glGetString(GL_VERSION) << std::endl;
	std::cout << "Supported GLSL version is: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << std::endl;
	while (!glfwWindowShouldClose(window))
	{
		display();
		// 点击后运动
		if(is_click)
			motion(window);
		// 交换颜色缓冲 以及 检查有没有触发什么事件（比如键盘输入、鼠标移动等）
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	return 0;
}

