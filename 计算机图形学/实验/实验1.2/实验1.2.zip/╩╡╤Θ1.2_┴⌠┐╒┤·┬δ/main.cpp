#define  _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
// #include <unistd.h>

int bugs;

//void init()
//{
//    setbuf(stdin, NULL);
//    setbuf(stdout, NULL);
//    setbuf(stderr, NULL);
//}

void options()
{
    puts("你的回合: ");
    puts("----------1.攻击----------");
    puts("----------2.放弃----------");
}

void attack()
{
    int size;
    puts("请输入攻击强度: ");
    scanf("%d", &size);
    if (size >= bugs / 2)
    {
        puts("醒醒, 你练度没这么高.");
        return;
    }
    bugs = bugs - size;
    return;
}

void fail()
{
    puts("战斗失败.");
    puts("去提升下等级和遗器再来挑战吧.");
    exit(0);
}

void success()
{
    puts("战斗胜利!");
    system("cat /flag");
    exit(0);
}

void check()
{
    puts("checked");
    if (bugs < 0)
    {
        success();
    }
    return;
}

int main()
{
    bugs = 3;
    int turns = 20;
    while (1)
    {
        if (turns <= 0)
        {
            puts("敌人陷入狂暴,攻击力大幅提升.");
            fail();
        }
        else if (turns <= 3)
        {
            puts("注意: 敌人即将陷入狂暴!");
        }
        puts("!!被繁育的虫群出现了!!");
        bugs *= 2;
        printf("剩余回合: %d\n", turns);
        printf("当前虫群数量: %d\n", bugs);
        options();
        int op;
        scanf("%d", &op);
        if (op == 1)
        {
            attack();
        }
        else if (op == 2)fail();
        else
        {
            puts("兄啊放个技能都能点歪?");
            continue;
        }
        turns--;
        if (bugs < 0)
        {
            success();
        }
    }
    return 0;
}