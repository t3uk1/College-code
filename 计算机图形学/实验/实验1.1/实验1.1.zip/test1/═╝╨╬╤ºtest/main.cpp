#include <GL/glut.h>

// ���Ƶ�����
float controlPoints[3][2] = {
    {100, 100},   // P0
    {200, 300},   // P1
    {400, 100}    // P2
};

void drawBezierCurve()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glPointSize(5.0);
    glColor3f(1.0, 0.0, 0.0); // ����������ɫΪ��ɫ

    glBegin(GL_POINTS);
    for (float t = 0.0; t <= 1.0; t += 0.01)
    {
        // ���㱴���������ϵĵ�
        float x = (1 - t) * (1 - t) * controlPoints[0][0] + 2 * (1 - t) * t * controlPoints[1][0] + t * t * controlPoints[2][0];
        float y = (1 - t) * (1 - t) * controlPoints[0][1] + 2 * (1 - t) * t * controlPoints[1][1] + t * t * controlPoints[2][1];
        glVertex2f(x, y);
    }
    glEnd();

    glFlush();
}

void display()
{
    glClearColor(1.0, 1.0, 1.0, 1.0); // ���ñ�����ɫΪ��ɫ
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0, 0.0, 0.0); // ���ÿ��Ƶ���ɫΪ��ɫ

    glBegin(GL_POINTS);
    for (int i = 0; i < 3; i++)
    {
        glVertex2f(controlPoints[i][0], controlPoints[i][1]);
    }
    glEnd();

    drawBezierCurve();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Bezier Curve");
    gluOrtho2D(0, 800, 0, 600);
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}